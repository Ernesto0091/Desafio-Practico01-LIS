<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <title>Calculadora de Prestamos</title>
</head>
<body>
    <br><br>
    <header class="head">
        <h1 style="text-align: center;">Calculadora de tabla de amortización</h1>
    </header>
    <br>
    <section class="form">
        <form action="" method="POST">
            <h2>Detalles del prestamo</h2><br>
            <select name="TipoSistema[]" id="TipoSistema[]" class="form-select" aria-label="Default select example" style="width: 70%; font-size:30px; margin: 0 auto; border-radius:10px;" require>
                <option selected value="0">Elija el sistema de prestamo</option>
                <option value="Frances">Sistema Francés</option>
                <option value="Aleman">Sistema Alemán</option>
                <option value="Usa">Sistema Americano</option>
                <option value="Simple">Sistema Simple</option>
                <option value="Compuesto">Sistema Compuesto</option>
            </select><br>
            <label for="">Fecha de desembolso</label><br>
            <input type="date" name="FechaInicial" id="FechaInicial" require class="input"><br><br>
            <label for="">Capital entregado</label><br>
            <input type="number" name="capital" id="capital" require class="input"><br><br>
            <label for="">Periodo de pago</label>
            <select name="Ppago[]" id="Ppago[]" class="form-select" aria-label="Default select example" style="width: 70%; font-size:30px; margin: 0 auto; border-radius:10px;" require>
                <option value="0">Elija un periodo de desembolso</option>
                <option value="Diario">Diario</option>
                <option value="Semanal">Semanal</option>
                <option value="Quincenal">Quincenal</option>
                <option value="Mensual">Mensual</option>
                <option value="Anual">Anual</option>
            </select><br>
            <label for="">Interes: </label>
            <input type="number" name="interes" id="interes" require class="input">%
            <br><br>
            <label for="">Plazo: </label>
            <input type="number" name="Plazo" id="Plazo" require class="input">
            <br><br>
            <input type="submit" value="Calcular" name="calcular" class="btn btn-success" style="font-size: 30px; width:30%;">
            <br><br>
        </form>
    </section>
    <br>
    <?php
        
        echo "<section class=\"tablas\">";

        if(isset($_POST['calcular']))
        {
            $sistema = $_POST['TipoSistema'];

            for($i=0;$i<count($sistema);$i++)
            {
               $TipoPeriodo = $_POST['Ppago'];

               for($j=0;$j<count($TipoPeriodo);$j++)
               {

                    $Capital = $_POST['capital'];
                    $Plazo = $_POST['Plazo'];
                    $Interes = $_POST['interes']/100;
                    $fechaInicial = $_POST['FechaInicial'];
                    $InteresR = $Capital*$Interes;
                    $CuotaPago = ($Capital/$Plazo)+$InteresR;
                    $capProm = $Capital/$Plazo;
                    $saldo = $Capital - $capProm; 

                    /**Interes compuesto */
                    $CapitalC = $_POST['capital'];
                    $InteresInicialC = $_POST['interes']/100;
                    $PlazoC = $_POST['Plazo'];
                    $fechaInicialC = $_POST['FechaInicial'];
                    $f1 = 1+$InteresInicialC;
                    $InteresCompuesto = $CapitalC * pow($f1, $PlazoC);
                    $CoutaPagoCompuesto = ($CapitalC/$PlazoC)+$InteresCompuesto;
                    $capPromC = $CapitalC/$PlazoC;
                    $saldoC = $CapitalC - $capPromC; 
                    
                   if($sistema[$i]=="Frances" && $TipoPeriodo[$j]=="Diario" || $sistema[$i]=="Frances" && $TipoPeriodo[$j]=="Semanal" || $sistema[$i]=="Frances" && $TipoPeriodo[$j]=="Quincenal" || $sistema[$i]=="Frances" && $TipoPeriodo[$j]=="Mensual" || $sistema[$i]=="Frances" && $TipoPeriodo[$j]=="Anual")
                   {
                        echo "<h3> Fecha del prestamo : $fechaInicial (Interés simple)</h3>";
                        echo "<br>";
                        echo "<h3> Monto: $Capital</h3>";
                        echo "<br>";
                        echo "<h3> Periodo: $TipoPeriodo[$i]</h3>";
                        echo "<br>";
                        echo "<h3> Interés: $Interes</h3>";
                        echo "<br>";
                        echo "<h3> Plazo : $Plazo</h3>";
                        echo "<br>";
                       /*Interes simple */
                       $rows=1;
                        $tabla = "<table class=\"table table-dark table-striped\"><thead>";
                        $tabla .= "<th>Fecha de desembolso</th>";
                        $tabla .= "<th>Cuota de pago</th>";
                        $tabla .= "<th>Capital por periodo</th>";
                        $tabla .= "<th>Interés</th>";
                        $tabla .= "<th>Saldo disponible</th>";
                        $tabla .= "</thead><tbody>";
                        $tabla .= "<tr><td>";
                        $tabla .= $fechaInicial++ . "</td><td>";
                        $tabla .= $CuotaPago . "</td><td>";
                        $tabla .= $capProm. "</td><td>";
                        $tabla .= $Interes . "</td><td>";
                        $tabla .= $saldo <=0 ? "<--- Saldo no válido-": $saldo;
                        $rows ++;
                        $tabla .= "</td></tr>";
                        while($rows<=$Plazo)
                        {
                            $tabla .= "<tr><td>";
                            $tabla .= $fechaInicial++ . "</td><td>";
                            $tabla .= $CuotaPago . "</td><td>";
                            $tabla .= $capProm. "</td><td>";
                            $tabla .= $Interes . "</td><td>";
                            $tabla .= $saldo <=0 ? "<--- Saldo no válido-": $saldo = ($saldo- $capProm);
                            $rows ++;
                            $tabla .= "</td></tr>";
                        }
                        $tabla .= "</tbody></table>";
                        echo $tabla;
                        /****************************************** */
                        echo "<br>";
                        echo "";
                        echo "<h3> Fecha del prestamo : $fechaInicialC (Interés Compuesto)</h3>";
                        echo "<br>";
                        echo "<h3> Monto: $CapitalC</h3>";
                        echo "<br>";
                        echo "<h3> Periodo: $TipoPeriodo[$i]</h3>";
                        echo "<br>";
                        echo "<h3> Interés: $InteresCompuesto</h3>";
                        echo "<br>";
                        echo "<h3> Plazo : $PlazoC</h3>";
                        echo "<br>";
                        /*Interes Compuesto */
                        $Rows=1;
                        $tabla2 = "<table class=\"table table-dark table-striped\"><thead>";
                        $tabla2 .= "<th>Fecha de desembolso</th>";
                        $tabla2 .= "<th>Cuota de pago</th>";
                        $tabla2 .= "<th>Capital por periodo</th>";
                        $tabla2 .= "<th>Interés</th>";
                        $tabla2 .= "<th>Saldo disponible</th>";
                        $tabla2 .= "</thead><tbody>";
                        $tabla2 .= "<tr><td>";
                        $tabla2 .= $fechaInicialC++ . "</td><td>";
                        $tabla2 .= $CoutaPagoCompuesto . "</td><td>";
                        $tabla2 .= $capPromC. "</td><td>";
                        $tabla2 .= $InteresCompuesto . "</td><td>";
                        $tabla2 .= $saldoC <=0 ? "<--- Saldo no válido-": $saldoC;
                        $Rows ++;
                        $tabla2 .= "</td></tr>";
                        while($Rows<=$PlazoC)
                        {
                            $tabla2 .= "<tr><td>";
                            $tabla2 .= $fechaInicialC++ . "</td><td>";
                            $tabla2 .= $CoutaPagoCompuesto . "</td><td>";
                            $tabla2 .= $capPromC. "</td><td>";
                            $tabla2 .= $InteresCompuesto . "</td><td>";
                            $tabla2 .= $saldoC <=0 ? "<--- Saldo no válido-": $saldoC = ($saldoC- $capPromC);
                            $Rows ++;
                            $tabla2 .= "</td></tr>";
                        }
                        $tabla2 .= "</tbody></table>";
                        echo $tabla2;
                   }

                   if($sistema[$i]=="Aleman" && $TipoPeriodo[$j]=="Diario" || $sistema[$i]=="Aleman" && $TipoPeriodo[$j]=="Semanal" || $sistema[$i]=="Aleman" && $TipoPeriodo[$j]=="Quincenal" || $sistema[$i]=="Aleman" && $TipoPeriodo[$j]=="Mensual" || $sistema[$i]=="Aleman" && $TipoPeriodo[$j]=="Anual")
                   {

                        echo "<h3> Fecha del prestamo : $fechaInicial (Interés simple)</h3>";
                        echo "<br>";
                        echo "<h3> Monto: $Capital</h3>";
                        echo "<br>";
                        echo "<h3> Periodo: $TipoPeriodo[$i]</h3>";
                        echo "<br>";
                        echo "<h3> Interés: $Interes</h3>";
                        echo "<br>";
                        echo "<h3> Plazo : $Plazo</h3>";
                        echo "<br>";
                       /*Interes simple */
                       $rows=1;
                        $tabla = "<table class=\"table table-success table-striped\"><thead>";
                        $tabla .= "<th>Fecha de desembolso</th>";
                        $tabla .= "<th>Cuota de pago</th>";
                        $tabla .= "<th>Capital por periodo</th>";
                        $tabla .= "<th>Interés</th>";
                        $tabla .= "<th>Saldo disponible</th>";
                        $tabla .= "</thead><tbody>";
                        $tabla .= "<tr><td>";
                        $tabla .= $fechaInicial++ . "</td><td>";
                        $tabla .= $CuotaPago . "</td><td>";
                        $tabla .= $capProm. "</td><td>";
                        $tabla .= $Interes . "</td><td>";
                        $tabla .= $saldo <=0 ? "<--- Saldo no válido-": $saldo;
                        $rows ++;
                        $tabla .= "</td></tr>";
                        while($rows<=$Plazo)
                        {
                            $tabla .= "<tr><td>";
                            $tabla .= $fechaInicial++ . "</td><td>";
                            $tabla .= $CuotaPago . "</td><td>";
                            $tabla .= $capProm. "</td><td>";
                            $tabla .= $Interes . "</td><td>";
                            $tabla .= $saldo <=0 ? "<--- Saldo no válido-": $saldo = ($saldo- $capProm);
                            $rows ++;
                            $tabla .= "</td></tr>";
                        }
                        $tabla .= "</tbody></table>";
                        echo $tabla;
                        /****************************************** */
                        echo "<br>";
                        echo "";

                        echo "<br>";
                        echo "";
                        echo "<h3> Fecha del prestamo : $fechaInicialC (Interés Compuesto)</h3>";
                        echo "<br>";
                        echo "<h3> Monto: $CapitalC</h3>";
                        echo "<br>";
                        echo "<h3> Periodo: $TipoPeriodo[$i]</h3>";
                        echo "<br>";
                        echo "<h3> Interés: $InteresCompuesto</h3>";
                        echo "<br>";
                        echo "<h3> Plazo : $PlazoC</h3>";
                        echo "<br>";
                        /*Interes Compuesto */
                        $Rows=1;
                        $tabla2 = "<table class=\"table table-success table-striped\"><thead>";
                        $tabla2 .= "<th>Fecha de desembolso</th>";
                        $tabla2 .= "<th>Cuota de pago</th>";
                        $tabla2 .= "<th>Capital por periodo</th>";
                        $tabla2 .= "<th>Interés</th>";
                        $tabla2 .= "<th>Saldo disponible</th>";
                        $tabla2 .= "</thead><tbody>";
                        $tabla2 .= "<tr><td>";
                        $tabla2 .= $fechaInicialC++ . "</td><td>";
                        $tabla2 .= $CoutaPagoCompuesto . "</td><td>";
                        $tabla2 .= $capPromC. "</td><td>";
                        $tabla2 .= $InteresCompuesto . "</td><td>";
                        $tabla2 .= $saldoC <=0 ? "<--- Saldo no válido-": $saldoC;
                        $Rows ++;
                        $tabla2 .= "</td></tr>";
                        while($Rows<=$PlazoC)
                        {
                            $tabla2 .= "<tr><td>";
                            $tabla2 .= $fechaInicialC++ . "</td><td>";
                            $tabla2 .= $CoutaPagoCompuesto . "</td><td>";
                            $tabla2 .= $capPromC. "</td><td>";
                            $tabla2 .= $InteresCompuesto . "</td><td>";
                            $tabla2 .= $saldoC <=0 ? "<--- Saldo no válido-": $saldoC = ($saldoC- $capPromC);
                            $Rows ++;
                            $tabla2 .= "</td></tr>";
                        }
                        $tabla2 .= "</tbody></table>";
                        echo $tabla2;
                   }

                   if($sistema[$i]=="Usa" && $TipoPeriodo[$j]=="Diario" || $sistema[$i]=="Usa" && $TipoPeriodo[$j]=="Semanal" || $sistema[$i]=="Usa" && $TipoPeriodo[$j]=="Quincenal" || $sistema[$i]=="Usa" && $TipoPeriodo[$j]=="Mensual" || $sistema[$i]=="Usa" && $TipoPeriodo[$j]=="Anual")
                   {
                        echo "<h3> Fecha del prestamo : $fechaInicial (Interés simple)</h3>";
                        echo "<br>";
                        echo "<h3> Monto: $Capital</h3>";
                        echo "<br>";
                        echo "<h3> Periodo: $TipoPeriodo[$i]</h3>";
                        echo "<br>";
                        echo "<h3> Interés: $Interes</h3>";
                        echo "<br>";
                        echo "<h3> Plazo : $Plazo</h3>";
                        echo "<br>";
                       /*Interes simple */
                       $rows=1;
                        $tabla = "<table class=\"table table-dark table-hover\"><thead>";
                        $tabla .= "<th>Fecha de desembolso</th>";
                        $tabla .= "<th>Cuota de pago</th>";
                        $tabla .= "<th>Capital por periodo</th>";
                        $tabla .= "<th>Interés</th>";
                        $tabla .= "<th>Saldo disponible</th>";
                        $tabla .= "</thead><tbody>";
                        $tabla .= "<tr><td>";
                        $tabla .= $fechaInicial++ . "</td><td>";
                        $tabla .= $CuotaPago . "</td><td>";
                        $tabla .= $capProm. "</td><td>";
                        $tabla .= $Interes . "</td><td>";
                        $tabla .= $saldo <=0 ? "<--- Saldo no válido-": $saldo;
                        $rows ++;
                        $tabla .= "</td></tr>";
                        while($rows<=$Plazo)
                        {
                            $tabla .= "<tr><td>";
                            $tabla .= $fechaInicial++ . "</td><td>";
                            $tabla .= $CuotaPago . "</td><td>";
                            $tabla .= $capProm. "</td><td>";
                            $tabla .= $Interes . "</td><td>";
                            $tabla .= $saldo <=0 ? "<--- Saldo no válido-": $saldo = ($saldo- $capProm);
                            $rows ++;
                            $tabla .= "</td></tr>";
                        }
                        $tabla .= "</tbody></table>";
                        echo $tabla;
                        /****************************************** */
                        echo "<br>";
                        echo "";

                        echo "<br>";
                        echo "";
                        echo "<h3> Fecha del prestamo : $fechaInicialC (Interés Compuesto)</h3>";
                        echo "<br>";
                        echo "<h3> Monto: $CapitalC</h3>";
                        echo "<br>";
                        echo "<h3> Periodo: $TipoPeriodo[$i]</h3>";
                        echo "<br>";
                        echo "<h3> Interés: $InteresCompuesto</h3>";
                        echo "<br>";
                        echo "<h3> Plazo : $PlazoC</h3>";
                        echo "<br>";
                        /*Interes Compuesto */
                        $Rows=1;
                        $tabla2 = "<table class=\"table table-dark table-hover\"><thead>";
                        $tabla2 .= "<th>Fecha de desembolso</th>";
                        $tabla2 .= "<th>Cuota de pago</th>";
                        $tabla2 .= "<th>Capital por periodo</th>";
                        $tabla2 .= "<th>Interés</th>";
                        $tabla2 .= "<th>Saldo disponible</th>";
                        $tabla2 .= "</thead><tbody>";
                        $tabla2 .= "<tr><td>";
                        $tabla2 .= $fechaInicialC++ . "</td><td>";
                        $tabla2 .= $CoutaPagoCompuesto . "</td><td>";
                        $tabla2 .= $capPromC. "</td><td>";
                        $tabla2 .= $InteresCompuesto . "</td><td>";
                        $tabla2 .= $saldoC <=0 ? "<--- Saldo no válido-": $saldoC;
                        $Rows ++;
                        $tabla2 .= "</td></tr>";
                        while($Rows<=$PlazoC)
                        {
                            $tabla2 .= "<tr><td>";
                            $tabla2 .= $fechaInicialC++ . "</td><td>";
                            $tabla2 .= $CoutaPagoCompuesto . "</td><td>";
                            $tabla2 .= $capPromC. "</td><td>";
                            $tabla2 .= $InteresCompuesto . "</td><td>";
                            $tabla2 .= $saldoC <=0 ? "<--- Saldo no válido-": $saldoC = ($saldoC- $capPromC);
                            $Rows ++;
                            $tabla2 .= "</td></tr>";
                        }
                        $tabla2 .= "</tbody></table>";
                        echo $tabla2;
                   }

                   if($sistema[$i]=="Simple" && $TipoPeriodo[$j]=="Diario" || $sistema[$i]=="Simple" && $TipoPeriodo[$j]=="Semanal" || $sistema[$i]=="Simple" && $TipoPeriodo[$j]=="Quincenal" || $sistema[$i]=="Simple" && $TipoPeriodo[$j]=="Mensual" || $sistema[$i]=="Simple" && $TipoPeriodo[$j]=="Anual")
                   {
                        echo "<h3> Fecha del prestamo : $fechaInicial (Interés simple)</h3>";
                        echo "<br>";
                        echo "<h3> Monto: $Capital</h3>";
                        echo "<br>";
                        echo "<h3> Periodo: $TipoPeriodo[$i]</h3>";
                        echo "<br>";
                        echo "<h3> Interés: $Interes</h3>";
                        echo "<br>";
                        echo "<h3> Plazo : $Plazo</h3>";
                        echo "<br>";
                       /*Interes simple */
                       $rows=1;
                        $tabla = "<table class=\"table table-striped table-hover\"><thead>";
                        $tabla .= "<th>Fecha de desembolso</th>";
                        $tabla .= "<th>Cuota de pago</th>";
                        $tabla .= "<th>Capital por periodo</th>";
                        $tabla .= "<th>Interés</th>";
                        $tabla .= "<th>Saldo disponible</th>";
                        $tabla .= "</thead><tbody>";
                        $tabla .= "<tr><td>";
                        $tabla .= $fechaInicial++ . "</td><td>";
                        $tabla .= $CuotaPago . "</td><td>";
                        $tabla .= $capProm. "</td><td>";
                        $tabla .= $Interes . "</td><td>";
                        $tabla .= $saldo <=0 ? "<--- Saldo no válido-": $saldo;
                        $rows ++;
                        $tabla .= "</td></tr>";
                        while($rows<=$Plazo)
                        {
                            $tabla .= "<tr><td>";
                            $tabla .= $fechaInicial++ . "</td><td>";
                            $tabla .= $CuotaPago . "</td><td>";
                            $tabla .= $capProm. "</td><td>";
                            $tabla .= $Interes . "</td><td>";
                            $tabla .= $saldo <=0 ? "<--- Saldo no válido-": $saldo = ($saldo- $capProm);
                            $rows ++;
                            $tabla .= "</td></tr>";
                        }
                        $tabla .= "</tbody></table>";
                        echo $tabla;
                        /****************************************** */
                        echo "<br>";
                        echo "";

                        echo "<br>";
                        echo "";
                        echo "<h3> Fecha del prestamo : $fechaInicialC (Interés Compuesto)</h3>";
                        echo "<br>";
                        echo "<h3> Monto: $CapitalC</h3>";
                        echo "<br>";
                        echo "<h3> Periodo: $TipoPeriodo[$i]</h3>";
                        echo "<br>";
                        echo "<h3> Interés: $InteresCompuesto</h3>";
                        echo "<br>";
                        echo "<h3> Plazo : $PlazoC</h3>";
                        echo "<br>";
                        /*Interes Compuesto */
                        $Rows=1;
                        $tabla2 = "<table class=\"table table-striped table-hover\"><thead>";
                        $tabla2 .= "<th>Fecha de desembolso</th>";
                        $tabla2 .= "<th>Cuota de pago</th>";
                        $tabla2 .= "<th>Capital por periodo</th>";
                        $tabla2 .= "<th>Interés</th>";
                        $tabla2 .= "<th>Saldo disponible</th>";
                        $tabla2 .= "</thead><tbody>";
                        $tabla2 .= "<tr><td>";
                        $tabla2 .= $fechaInicialC++ . "</td><td>";
                        $tabla2 .= $CoutaPagoCompuesto . "</td><td>";
                        $tabla2 .= $capPromC. "</td><td>";
                        $tabla2 .= $InteresCompuesto . "</td><td>";
                        $tabla2 .= $saldoC <=0 ? "<--- Saldo no válido-": $saldoC;
                        $Rows ++;
                        $tabla2 .= "</td></tr>";
                        while($Rows<=$PlazoC)
                        {
                            $tabla2 .= "<tr><td>";
                            $tabla2 .= $fechaInicialC++ . "</td><td>";
                            $tabla2 .= $CoutaPagoCompuesto . "</td><td>";
                            $tabla2 .= $capPromC. "</td><td>";
                            $tabla2 .= $InteresCompuesto . "</td><td>";
                            $tabla2 .= $saldoC <=0 ? "<--- Saldo no válido-": $saldoC = ($saldoC- $capPromC);
                            $Rows ++;
                            $tabla2 .= "</td></tr>";
                        }
                        $tabla2 .= "</tbody></table>";
                        echo $tabla2;
                   }

                   if($sistema[$i]=="Compuesto" && $TipoPeriodo[$j]=="Diario" || $sistema[$i]=="Compuesto" && $TipoPeriodo[$j]=="Semanal" || $sistema[$i]=="Compuesto" && $TipoPeriodo[$j]=="Quincenal" || $sistema[$i]=="Compuesto" && $TipoPeriodo[$j]=="Mensual" || $sistema[$i]=="Compuesto" && $TipoPeriodo[$j]=="Anual")
                   {
                        echo "<h3> Fecha del prestamo : $fechaInicial (Interés simple)</h3>";
                        echo "<br>";
                        echo "<h3> Monto: $Capital</h3>";
                        echo "<br>";
                        echo "<h3> Periodo: $TipoPeriodo[$i]</h3>";
                        echo "<br>";
                        echo "<h3> Interés: $Interes</h3>";
                        echo "<br>";
                        echo "<h3> Plazo : $Plazo</h3>";
                        echo "<br>";
                       /*Interes simple */
                       $rows=1;
                        $tabla = "<table class=\"table table-bordered border-primary\"><thead>";
                        $tabla .= "<th>Fecha de desembolso</th>";
                        $tabla .= "<th>Cuota de pago</th>";
                        $tabla .= "<th>Capital por periodo</th>";
                        $tabla .= "<th>Interés</th>";
                        $tabla .= "<th>Saldo disponible</th>";
                        $tabla .= "</thead><tbody>";
                        $tabla .= "<tr><td>";
                        $tabla .= $fechaInicial++ . "</td><td>";
                        $tabla .= $CuotaPago . "</td><td>";
                        $tabla .= $capProm. "</td><td>";
                        $tabla .= $Interes . "</td><td>";
                        $tabla .= $saldo <=0 ? "<--- Saldo no válido-": $saldo;
                        $rows ++;
                        $tabla .= "</td></tr>";
                        while($rows<=$Plazo)
                        {
                            $tabla .= "<tr><td>";
                            $tabla .= $fechaInicial++ . "</td><td>";
                            $tabla .= $CuotaPago . "</td><td>";
                            $tabla .= $capProm. "</td><td>";
                            $tabla .= $Interes . "</td><td>";
                            $tabla .= $saldo <=0 ? "<--- Saldo no válido-": $saldo = ($saldo- $capProm);
                            $rows ++;
                            $tabla .= "</td></tr>";
                        }
                        $tabla .= "</tbody></table>";
                        echo $tabla;
                        /****************************************** */
                        echo "<br>";
                        echo "";

                        echo "<br>";
                        echo "";
                        echo "<h3> Fecha del prestamo : $fechaInicialC (Interés Compuesto)</h3>";
                        echo "<br>";
                        echo "<h3> Monto: $CapitalC</h3>";
                        echo "<br>";
                        echo "<h3> Periodo: $TipoPeriodo[$i]</h3>";
                        echo "<br>";
                        echo "<h3> Interés: $InteresCompuesto</h3>";
                        echo "<br>";
                        echo "<h3> Plazo : $PlazoC</h3>";
                        echo "<br>";
                        /*Interes Compuesto */
                        $Rows=1;
                        $tabla2 = "<table class=\"table table-bordered border-primary\"><thead>";
                        $tabla2 .= "<th>Fecha de desembolso</th>";
                        $tabla2 .= "<th>Cuota de pago</th>";
                        $tabla2 .= "<th>Capital por periodo</th>";
                        $tabla2 .= "<th>Interés</th>";
                        $tabla2 .= "<th>Saldo disponible</th>";
                        $tabla2 .= "</thead><tbody>";
                        $tabla2 .= "<tr><td>";
                        $tabla2 .= $fechaInicialC++ . "</td><td>";
                        $tabla2 .= $CoutaPagoCompuesto . "</td><td>";
                        $tabla2 .= $capPromC. "</td><td>";
                        $tabla2 .= $InteresCompuesto . "</td><td>";
                        $tabla2 .= $saldoC <=0 ? "<--- Saldo no válido-": $saldoC;
                        $Rows ++;
                        $tabla2 .= "</td></tr>";
                        while($Rows<=$PlazoC)
                        {
                            $tabla2 .= "<tr><td>";
                            $tabla2 .= $fechaInicialC++ . "</td><td>";
                            $tabla2 .= $CoutaPagoCompuesto . "</td><td>";
                            $tabla2 .= $capPromC. "</td><td>";
                            $tabla2 .= $InteresCompuesto . "</td><td>";
                            $tabla2 .= $saldoC <=0 ? "<--- Saldo no válido-": $saldoC = ($saldoC- $capPromC);
                            $Rows ++;
                            $tabla2 .= "</td></tr>";
                        }
                        $tabla2 .= "</tbody></table>";
                        echo $tabla2;
                   }


               }
            }
        
        }
        else
        {
            echo "Hello!";
        }

        echo "</section>";

    ?>

</body>
</html>