<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <title>Conversión de divisas</title>
</head>
<body>
    <br><br>
    <header class="head">
        <h1 style="text-align: center;">Conversión de divisas
        </h1>
    </header>
    <br>
    <section>
        <article>
            <div class="container">

                <form action="" method="POST">
                    <h2 style="text-align: center;">MiConversor</h2><br>
                    <div class="row">
                        <div class="col-6">
                        <select name="MonedaP[]" id="MonedaP[]" class="form-select" aria-label="Default select example" style="font-size: 25px;">
                            <option selected value="0">Elige tu moneda a convertir</option>
                            <option value="Dolar">Dolar $</option>
                            <option value="Euro">Euro €</option>
                            <option value="Yen">Yen ¥</option>
                            <option value="Libra">Libra Esterlina £</option>
                            
                        </select>
                        </div>
                        <div class="col-6">
                        <select name="MonedaS[]" id="MonedaS[]" class="form-select" aria-label="Default select example" style="font-size: 25px;">
                            <option selected value="0">Elige tu nueva moneda</option>
                            <option value="1">Dolar $</option>
                            <option value="2">Euro €</option>
                            <option value="3">Yen ¥</option>
                            <option value="4">Libra Esterlina £</option>
        
                        </select>
                        </div>
                
                    </div>
                    <br>
                    <article class="Peticion">
                        <label for=""><h3>Ingresa la cantidad a convertir</h3></label><br><br>
                        <input type="number" name="Cantidad" id="Cantidad" placeholder="123" class="number"/>       
                        <input type="submit" name="enviar" id="enviar" value="Convertir" class="btn btn-success" style="width: 130px; height: 60px; font-size: 20px;">
                    </article>
                </form>
                <br>
                <?php
                    
                    if(isset($_POST['enviar']))
                    {


                        /* Capturando la cantidad a convertir*/

                        $Cantidad = $_POST['Cantidad'];
                        

                    $numero1 = $_POST['MonedaP'];

                    for ($i=0;$i<count($numero1);$i++) 
                        { 
                        
                            $numero2 = $_POST['MonedaS'];

                            for($j=0;$j<count($numero2); $j++)
                            {
                                if($numero1[$i]=="Dolar" && $numero2[$j]==1)
                                {
                                    echo "<h1> La Cantidad Convertida es: $".$Cantidad."</h1>";
                                }
                                if($numero1[$i]=="Dolar" && $numero2[$j]==2)
                                {
                                    $DE = $Cantidad*0.88;
                                    echo "<h1>Tu cantidad convertida es: €".$DE."</h1>";

                                }
                                if($numero1[$i]=="Dolar" && $numero2[$j]==3)
                                {
                                    $DY = $Cantidad*115.68;
                                    echo "Tu cantidad convertida es: ¥".$DY;
                                }
                                if($numero1[$i]=="Dolar" && $numero2[$j]==4)
                                {
                                    $DL = $Cantidad*0.74;
                                    echo "<h1>Tu cantidad convertida es: £".$DL."</h1>";   
                                }

                                /*-------------------------------------- */

                                if($numero1[$i]=="Euro" && $numero2[$j]==1)
                                {
                                    $ED = $Cantidad*1.14;
                                    echo "<h1>Tu cantidad convertida es: $".$ED ."</h1>";
                                }
                                if($numero1[$i]=="Euro" && $numero2[$j]==2)
                                {
                                    echo "<h1>La cantidad convertida es: €".$Cantidad."</h1>";

                                }
                                if($numero1[$i]=="Euro" && $numero2[$j]==3)
                                {
                                    $EY = $Cantidad*131.28;
                                    echo "<h1>Tu cantidad convertida es: ¥".$EY."</h1>";
                                }
                                if($numero1[$i]=="Euro" && $numero2[$j]==4)
                                {
                                    $EL = $Cantidad*0.84;
                                    echo "<h1>Tu cantidad convertida es: £".$EL."</h1>";   
                                }

                                /**-------------------------------------- */

                                if($numero1[$i]=="Yen" && $numero2[$j]==1)
                                {
                                    $YD = $Cantidad*0.0086;
                                    echo "<h1>Tu cantidad convertida es: $".$YD."</h1>";
                                }
                                if($numero1[$i]=="Yen" && $numero2[$j]==2)
                                {
                                    $YE = $Cantidad*0.0076;
                                    echo "<h1>Tu cantidad convertida es: €".$YE."</h1>";
                                }
                                if($numero1[$i]=="Yen" && $numero2[$j]==3)
                                {
                                    echo "<h1>La cantidad convertida es: ¥".$Cantidad."</h1>";

                                }
                                if($numero1[$i]=="Yen" && $numero2[$j]==4)
                                {
                                    $YL = $Cantidad*0.0064;
                                    echo "<h1>Tu cantidad convertida es: £".$YL."</h1>";   
                                }

                                /**------------------------------------- */

                                if($numero1[$i]=="Libra" && $numero2[$j]==1)
                                {
                                    $LD = $Cantidad*1.35;
                                    echo "<h1>Tu cantidad convertida es: $".$LD."</h1>";
                                }
                                if($numero1[$i]=="Libra" && $numero2[$j]==2)
                                {
                                    $LE = $Cantidad*1.19;
                                    echo "<h1>Tu cantidad convertida es: €".$LE."</h1>";
                                }
                                if($numero1[$i]=="Libra" && $numero2[$j]==3)
                                {
                                    $LY = $Cantidad*156.72;
                                    echo "<h1>Tu cantidad convertida es: ¥".$LY."</h1>";

                                }
                                if($numero1[$i]=="Libra" && $numero2[$j]==4)
                                {
                                    echo "<h1>La cantidad cpnvertida es: £".$Cantidad."</h1>"; 
                                }

                            
                            }
                        
                        } 
                    

                    }
                    else
                    {
                    echo "no accede";
                    }

                ?>
        
                <br><br>
            </div>

        </article>
    </section>

    
</body>
</html>