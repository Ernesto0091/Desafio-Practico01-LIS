 <?php


    if(isset($_POST['enviar']))
    {


        /* Capturando la cantidad a convertir*/

        $Cantidad = $_POST['Cantidad'];
        

      $numero1 = $_POST['MonedaP'];

      for ($i=0;$i<count($numero1);$i++) 
      	{ 
      	   
            $numero2 = $_POST['MonedaS'];

            for($j=0;$j<count($numero2); $j++)
            {
                if($numero1[$i]=="Dolar" && $numero2[$j]==1)
                {
                    echo "<h1>".$Cantidad."</h1>";
                }
                if($numero1[$i]=="Dolar" && $numero2[$j]==2)
                {
                    $DE = $Cantidad*0.88;
                    echo "Tu cantidad convertida es: ".$DE;

                }
                if($numero1[$i]=="Dolar" && $numero2[$j]==3)
                {
                    $DY = $Cantidad*115.68;
                    echo "Tu cantidad convertida es: ".$DY;
                }
                if($numero1[$i]=="Dolar" && $numero2[$j]==4)
                {
                    $DL = $Cantidad*0.74;
                    echo "Tu cantidad convertida es: ".$DL;   
                }

                /*-------------------------------------- */

                if($numero1[$i]=="Euro" && $numero2[$j]==1)
                {
                    $ED = $Cantidad*1.14;
                    echo "Tu cantidad convertida es: ".$ED;
                }
                if($numero1[$i]=="Euro" && $numero2[$j]==2)
                {
                    echo "<h1>".$Cantidad."</h1>";

                }
                if($numero1[$i]=="Euro" && $numero2[$j]==3)
                {
                    $EY = $Cantidad*131.28;
                    echo "Tu cantidad convertida es: ".$EY;
                }
                if($numero1[$i]=="Euro" && $numero2[$j]==4)
                {
                    $EL = $Cantidad*0.84;
                    echo "Tu cantidad convertida es: ".$EL;   
                }

                /**-------------------------------------- */

                if($numero1[$i]=="Yen" && $numero2[$j]==1)
                {
                    $YD = $Cantidad*0.0086;
                    echo "Tu cantidad convertida es: ".$YD;
                }
                if($numero1[$i]=="Yen" && $numero2[$j]==2)
                {
                    $YE = $Cantidad*0.0076;
                    echo "Tu cantidad convertida es: ".$YE;
                }
                if($numero1[$i]=="Yen" && $numero2[$j]==3)
                {
                    echo "<h1>".$Cantidad."</h1>";

                }
                if($numero1[$i]=="Yen" && $numero2[$j]==4)
                {
                    $YL = $Cantidad*0.0064;
                    echo "Tu cantidad convertida es: ".$YL;   
                }

                /**------------------------------------- */

                if($numero1[$i]=="Libra" && $numero2[$j]==1)
                {
                    $LD = $Cantidad*1.35;
                    echo "Tu cantidad convertida es: ".$LD;
                }
                if($numero1[$i]=="Libra" && $numero2[$j]==2)
                {
                    $LE = $Cantidad*1.19;
                    echo "Tu cantidad convertida es: ".$LE;
                }
                if($numero1[$i]=="Libra" && $numero2[$j]==3)
                {
                    $LE = $Cantidad*156.72;
                    echo "Tu cantidad convertida es: ".$LE;

                }
                if($numero1[$i]=="Libra" && $numero2[$j]==4)
                {
                    echo "<h1>".$Cantidad."</h1>"; 
                }

               
            }
         
      	} 
     

    }
    else
    {
       echo "no accede";
    }

 ?>
    
